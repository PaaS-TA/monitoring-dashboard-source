## BOSH Lite on VirtualBox

Instructions moved to <https://bosh.io/docs/bosh-lite>.
