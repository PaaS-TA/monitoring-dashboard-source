package loggregator_v2

//go:generate ./generate.sh
