package models

type Version struct {
	CurrentVersion int64
}
