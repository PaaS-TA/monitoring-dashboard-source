package eventhub

type Event interface{}
