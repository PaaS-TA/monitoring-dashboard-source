package locket // import "code.cloudfoundry.org/locket"
