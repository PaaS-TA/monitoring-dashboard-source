package lock // import "code.cloudfoundry.org/locket/lock"
