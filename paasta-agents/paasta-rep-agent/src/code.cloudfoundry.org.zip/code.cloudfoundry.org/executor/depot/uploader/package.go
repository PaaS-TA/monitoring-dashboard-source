package uploader // import "code.cloudfoundry.org/executor/depot/uploader"
