package configuration // import "code.cloudfoundry.org/executor/initializer/configuration"
