package server_test

func uint64ptr(n uint64) *uint64 {
	return &n
}
