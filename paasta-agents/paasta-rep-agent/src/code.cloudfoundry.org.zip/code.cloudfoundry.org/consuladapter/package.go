package consuladapter // import "code.cloudfoundry.org/consuladapter"
