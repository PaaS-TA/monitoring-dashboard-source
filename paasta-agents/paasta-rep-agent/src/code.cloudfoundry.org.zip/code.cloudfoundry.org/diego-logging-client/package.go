package diego_logging_client // import "code.cloudfoundry.org/diego-logging-client"
