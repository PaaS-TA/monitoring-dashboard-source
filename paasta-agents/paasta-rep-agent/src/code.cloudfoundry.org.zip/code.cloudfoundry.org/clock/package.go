package clock // import "code.cloudfoundry.org/clock"
