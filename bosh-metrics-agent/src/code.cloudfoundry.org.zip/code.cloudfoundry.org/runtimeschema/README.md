runtime-schema
==============
**Note**: This repository should be imported as `code.cloudfoundry.org/runtimeschema`.

Shared golang schema for runtime.

BBS for diego.

####Learn more about Diego and its components at [diego-design-notes](https://github.com/cloudfoundry/diego-design-notes)
