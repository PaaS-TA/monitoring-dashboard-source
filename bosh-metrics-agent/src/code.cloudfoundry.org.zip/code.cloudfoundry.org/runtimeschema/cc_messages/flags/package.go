package flags // import "code.cloudfoundry.org/runtimeschema/cc_messages/flags"
