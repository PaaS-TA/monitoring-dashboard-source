package cc_messages

const AppLRPDomain = "cf-apps"
const StagingTaskDomain = "cf-app-staging"
const RunningTaskDomain = "cf-tasks"
