package cc_messages

const CcBuildArtifactsUploadUriKey = "cc-build-artifacts-upload-uri"
const CcDropletUploadUriKey = "cc-droplet-upload-uri"

const CcTimeoutKey = "timeout"
