package truncate // import "code.cloudfoundry.org/lager/internal/truncate"
