package admin // import "github.com/influxdata/influxdb/services/admin"

//go:generate statik -src=assets
//go:generate go fmt statik/statik.go
