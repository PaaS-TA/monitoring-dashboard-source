package node

type Node struct {
	Id int
}

type NodeOrderedSet []Node
