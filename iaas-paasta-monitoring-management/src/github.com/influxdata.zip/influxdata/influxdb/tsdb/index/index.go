package index // import "github.com/influxdata/influxdb/tsdb/index"

import (
	_ "github.com/influxdata/influxdb/tsdb/index/inmem"
	_ "github.com/influxdata/influxdb/tsdb/index/tsi1"
)
