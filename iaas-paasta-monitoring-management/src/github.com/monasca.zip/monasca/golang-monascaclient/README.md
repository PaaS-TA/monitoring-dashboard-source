### Golang bindings to the Monasca API

This is a client library built to interface with the Monasca API. It provides a Go API (the monascaclient module).

#### Install
```go get github.com/monasca/golang-monascaclient```
