// The v1 package contains acceptance tests for the Openstack Cinder V1 service.

package v1
