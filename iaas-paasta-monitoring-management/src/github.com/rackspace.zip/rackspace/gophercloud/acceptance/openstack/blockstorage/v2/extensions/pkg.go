// The extensions package contains acceptance tests for the Openstack Cinder V2 extensions service.

package extensions
