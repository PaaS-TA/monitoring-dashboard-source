Here be acceptance tests for the image service API.
