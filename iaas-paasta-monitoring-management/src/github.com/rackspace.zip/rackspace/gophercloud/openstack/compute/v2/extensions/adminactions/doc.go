/*
Package provides access to the "Admin Actions" of the Compute API,
including migrations, live-migrations, reset-state, etc.
*/
package adminactions
