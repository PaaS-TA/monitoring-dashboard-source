// Package tenantnetworks provides the ability for tenants to see information about the networks they have access to
package tenantnetworks
