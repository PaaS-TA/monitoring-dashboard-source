// Package floatingip provides the ability to manage floating ips through
// nova-network
package floatingip
