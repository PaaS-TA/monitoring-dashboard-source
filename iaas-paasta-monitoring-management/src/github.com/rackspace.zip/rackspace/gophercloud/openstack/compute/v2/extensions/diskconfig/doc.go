// Package diskconfig provides information and interaction with the Disk
// Config extension that works with the OpenStack Compute service.
package diskconfig
