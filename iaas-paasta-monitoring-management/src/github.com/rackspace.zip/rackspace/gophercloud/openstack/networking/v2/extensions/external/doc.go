// Package external provides information and interaction with the external
// extension for the OpenStack Networking service.
package external
