// Package fwaas provides information and interaction with the Firewall
// as a Service extension for the OpenStack Networking service.
package fwaas
