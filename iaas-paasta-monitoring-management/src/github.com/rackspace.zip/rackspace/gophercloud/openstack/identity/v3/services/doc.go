// Package services provides information and interaction with the services API
// resource for the OpenStack Identity service.
package services
