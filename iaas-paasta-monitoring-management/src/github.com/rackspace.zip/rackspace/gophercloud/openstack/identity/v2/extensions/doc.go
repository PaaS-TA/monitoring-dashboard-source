// Package extensions provides information and interaction with the
// different extensions available for the OpenStack Identity service.
package extensions
