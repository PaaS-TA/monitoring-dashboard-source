// Package roles provides information and interaction with the roles API
// resource for the OpenStack Identity service.
package roles
