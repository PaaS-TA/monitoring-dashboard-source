// Package endpoints provides information and interaction with the service
// endpoints API resource in the OpenStack Identity service.
//
// For more information, see:
// http://developer.openstack.org/api-ref-identity-v3.html#endpoints-v3
package endpoints
