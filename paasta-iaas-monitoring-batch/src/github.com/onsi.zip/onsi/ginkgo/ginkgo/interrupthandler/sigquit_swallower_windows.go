// +build windows

package interrupthandler

func SwallowSigQuit() {
	//noop
}
