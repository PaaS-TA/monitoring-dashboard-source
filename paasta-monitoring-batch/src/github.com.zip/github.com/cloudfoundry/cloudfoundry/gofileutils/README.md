[![Build Status](https://travis-ci.org/cloudfoundry/gofileutils.png)](https://travis-ci.org/cloudfoundry/gofileutils)

Go File Utils
=============

A collection of go packages to simplify working with files.
