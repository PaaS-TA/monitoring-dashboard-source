// orchestration_stacktemplates_v1
package testing
