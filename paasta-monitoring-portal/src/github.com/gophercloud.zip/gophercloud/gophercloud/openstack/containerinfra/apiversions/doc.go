// Package apiversions provides information and interaction with the different
// API versions for the Container Infra service, code-named Magnum.
package apiversions
