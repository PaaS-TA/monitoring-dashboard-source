// Package v2 package contains acceptance tests for the Openstack Compute V2 service.
package v2
