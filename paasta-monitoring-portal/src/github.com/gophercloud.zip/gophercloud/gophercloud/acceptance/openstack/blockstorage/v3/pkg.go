// The v3 package contains acceptance tests for the OpenStack Cinder V3 service.

package v3
