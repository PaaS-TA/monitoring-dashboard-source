# Common Resources

This directory is for resources that are shared by multiple services.
