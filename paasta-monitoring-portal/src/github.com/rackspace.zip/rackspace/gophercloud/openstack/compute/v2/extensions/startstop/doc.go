/*
Package startstop provides functionality to start and stop servers that have
been provisioned by the OpenStack Compute service.
*/
package startstop
