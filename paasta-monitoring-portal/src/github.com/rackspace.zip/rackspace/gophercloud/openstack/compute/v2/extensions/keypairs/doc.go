// Package keypairs provides information and interaction with the Keypairs
// extension for the OpenStack Compute service.
package keypairs
