// Package flavors provides information and interaction with the database API
// resource in the OpenStack Database service.
//
// A database, when referred to here, refers to the database engine running on
// an instance.
package databases
